import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
INGEST = ROOT / "scripts" / "ingest_corpus.py"
ANALYZE = ROOT / "scripts" / "analyze_corpus.py"


class PipelineTest(unittest.TestCase):
    def test_ingest_redacts_and_deduplicates_then_analyzes(self):
        sample = (
            "A commuter bag should stay clear of the rear wheel and light. "
            "Email rider@example.com or message @ridername for the setup.\n\n"
            "A commuter bag should stay clear of the rear wheel and light. "
            "Email rider@example.com or message @ridername for the setup.\n"
        )
        with tempfile.TemporaryDirectory() as tmp:
            tmp_path = Path(tmp)
            source = tmp_path / "sample.txt"
            corpus = tmp_path / "sample.jsonl"
            report = tmp_path / "report.json"
            source.write_text(sample, encoding="utf-8")

            subprocess.run(
                [
                    sys.executable,
                    str(INGEST),
                    str(source),
                    "--output",
                    str(corpus),
                    "--source",
                    "test-source",
                    "--source-type",
                    "forum_comment",
                    "--permission-basis",
                    "user_owned",
                    "--locale",
                    "en-US",
                    "--discipline",
                    "commuting",
                    "--format",
                    "reply",
                    "--min-chars",
                    "20",
                ],
                check=True,
                capture_output=True,
                text=True,
            )

            rows = [json.loads(line) for line in corpus.read_text(encoding="utf-8").splitlines()]
            self.assertEqual(len(rows), 1)
            self.assertIn("[email]", rows[0]["text"])
            self.assertIn("[handle]", rows[0]["text"])
            self.assertNotIn("rider@example.com", rows[0]["text"])

            subprocess.run(
                [sys.executable, str(ANALYZE), str(corpus), "--output", str(report)],
                check=True,
                capture_output=True,
                text=True,
            )
            profile = json.loads(report.read_text(encoding="utf-8"))
            self.assertEqual(profile["records"], 1)
            self.assertEqual(profile["sources"], {"test-source": 1})
            self.assertGreater(profile["words"], 0)


if __name__ == "__main__":
    unittest.main()
